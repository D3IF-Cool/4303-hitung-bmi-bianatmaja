package org.d3if0021.kalkulatorbakarkalori.ui

import android.os.Bundle
import android.text.TextUtils
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import org.d3if0021.kalkulatorbakarkalori.R
import org.d3if0021.kalkulatorbakarkalori.data.kategoriBakarKalori
import org.d3if0021.kalkulatorbakarkalori.databinding.FragmentHitungBinding

class HitungFragment : Fragment() {

    private lateinit var binding: FragmentHitungBinding
    private lateinit var kategoriBakarKalori: kategoriBakarKalori

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.options_menu, menu)
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.menu_about) {
            findNavController().navigate(
                R.id.action_hitungFragment_to_aboutFragment)
            return true
        }
        return super.onOptionsItemSelected(item)
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHitungBinding.inflate(
            layoutInflater, container, false
        )
        binding.button.setOnClickListener { kalkulatorBakarKalori() }
        binding.saranButton.setOnClickListener { view: View ->
            view.findNavController().navigate(
                HitungFragmentDirections.actionHitungFragmentToSaranFragment(kategoriBakarKalori)
            )
        }
        setHasOptionsMenu(true)
        return binding.root
    }

    private fun kalkulatorBakarKalori() {

        val nama = binding.namaEditText.text.toString()
        if (TextUtils.isEmpty(nama)) {
            Toast.makeText(context, R.string.nama_invalid, Toast.LENGTH_LONG).show()
        }

        val berat = binding.beratEditText.text.toString()
        if (TextUtils.isEmpty(berat)) {
            Toast.makeText(context, R.string.berat_invalid, Toast.LENGTH_LONG).show()
            return
        }

        val jarak = binding.jarakEditText.text.toString()
        if (TextUtils.isEmpty(jarak)) {
            Toast.makeText(context, R.string.gender_invalid, Toast.LENGTH_LONG).show()
            return
        }
        val jarakKM = jarak.toFloat()
        val beratKG = berat.toFloat()


        val selectedId = binding.radioGroup.checkedRadioButtonId
        val isMale = selectedId == R.id.priaRadioButton
        val hitung = (beratKG * jarakKM) - ((beratKG * jarakKM) / 2) + beratKG + (beratKG / 2)
        +2.42
        val kategori = getKategori(hitung, isMale)

        binding.namaTextView.text = "Hai, " + nama
        binding.hitungTextView.text = getString(R.string.intro_hasil, hitung)
        binding.kategoriTextView.text = getString(R.string.kategori_x, kategori)
        binding.saranButton.visibility = View.VISIBLE
    }

    private fun getKategori(kalori: Float, isMale: Boolean): String {
        kategoriBakarKalori = if (isMale) {
            when {
                kalori < 300.0 -> org.d3if0021.kalkulatorbakarkalori.data.kategoriBakarKalori.KURANG
                kalori >= 310.0 -> org.d3if0021.kalkulatorbakarkalori.data.kategoriBakarKalori.LEBIH
                else -> org.d3if0021.kalkulatorbakarkalori.data.kategoriBakarKalori.PAS
            }
        } else {
            when {
                kalori < 280.0 -> org.d3if0021.kalkulatorbakarkalori.data.kategoriBakarKalori.KURANG
                kalori >= 300.0 -> org.d3if0021.kalkulatorbakarkalori.data.kategoriBakarKalori.LEBIH
                else -> org.d3if0021.kalkulatorbakarkalori.data.kategoriBakarKalori.PAS
            }
        }
        val stringRes = when (kategoriBakarKalori) {
            org.d3if0021.kalkulatorbakarkalori.data.kategoriBakarKalori.KURANG -> R.string.kurang
            org.d3if0021.kalkulatorbakarkalori.data.kategoriBakarKalori.PAS -> R.string.pas
            org.d3if0021.kalkulatorbakarkalori.data.kategoriBakarKalori.LEBIH -> R.string.lebih
        }
            return getString(stringRes)
        }
    }