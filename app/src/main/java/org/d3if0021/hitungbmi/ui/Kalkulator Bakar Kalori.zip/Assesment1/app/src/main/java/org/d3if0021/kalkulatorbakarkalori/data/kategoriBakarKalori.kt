package org.d3if0021.kalkulatorbakarkalori.data

enum class kategoriBakarKalori {KURANG, PAS, LEBIH }