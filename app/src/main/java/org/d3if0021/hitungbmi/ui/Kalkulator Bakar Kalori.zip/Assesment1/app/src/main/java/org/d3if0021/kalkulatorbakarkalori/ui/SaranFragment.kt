package org.d3if0021.kalkulatorbakarkalori.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.navArgs
import org.d3if0021.kalkulatorbakarkalori.R
import org.d3if0021.kalkulatorbakarkalori.data.kategoriBakarKalori
import org.d3if0021.kalkulatorbakarkalori.databinding.FragmentSaranBinding

class SaranFragment : Fragment() {

    private val args: SaranFragmentArgs by navArgs()
    private lateinit var binding: FragmentSaranBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        binding = FragmentSaranBinding.inflate(
            layoutInflater, container, false)
        updateUI(args.kategori)
        return binding.root
    }

    private fun updateUI(kategori: kategoriBakarKalori) {
        val actionBar = (requireActivity() as AppCompatActivity)
            .supportActionBar
        when (kategori) {
            kategoriBakarKalori.KURANG -> {
                actionBar?.title = getString(R.string.judul_kurang)
                binding.textView.text = getString(R.string.saran_kurang)
            }
            kategoriBakarKalori.PAS -> {
                actionBar?.title = getString(R.string.judul_pas)
                binding.textView.text = getString(R.string.saran_pas)
            }
            kategoriBakarKalori.LEBIH -> {
                actionBar?.title = getString(R.string.judul_lebih)
                binding.textView.text = getString(R.string.saran_lebih)
            }
        }
    }

}