package org.d3if0021.kalkulatorbakarkalori.ui

import androidx.fragment.app.Fragment
import org.d3if0021.kalkulatorbakarkalori.R

class AboutFragment : Fragment(R.layout.fragment_about)
